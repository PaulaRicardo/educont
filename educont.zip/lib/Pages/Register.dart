import 'package:flutter/material.dart';
import 'package:educont_app/behaviors/Scroll.dart';
import 'package:firebase_auth/firebase_auth.dart';

class RegisterPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => _RegisterPageState();
  }

class _RegisterPageState extends State<RegisterPage>{

final _formKey = GlobalKey<FormState>();
final _scaffoldKey = GlobalKey<ScaffoldState>();

  String _email;
  String _password;

  bool _isRegistering = false;

  _Register() async {
    if (_isRegistering) return;
    setState(() {
      _isRegistering = true;

    });

    _scaffoldKey.currentState.showSnackBar(
        SnackBar(
            content: Text('Registrando Usuario')));

    final form = _formKey.currentState;
    if (!form.validate()) {

      _scaffoldKey.currentState.hideCurrentSnackBar();
      setState(() {
        _isRegistering = true;
      });

      return;

  }

    form.save();

    try{

    await FirebaseAuth.instance.createUserWithEmailAndPassword(email:_email, password:_password);
    Navigator.of(context).pushReplacementNamed('/maintabs');
  } catch(e){

      _scaffoldKey.currentState.hideCurrentSnackBar();
      _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text(e),
        duration: Duration(seconds: 10),
        action: SnackBarAction(
            label: 'dissmi',
            onPressed: (){
              _scaffoldKey.currentState.hideCurrentSnackBar();
            }),

      ));

    } finally{

      setState(() {
        _isRegistering= false;

      });
    }

  }
    


  @override
  Widget build(BuildContext context) {

    return Scaffold (
      key: _scaffoldKey,
      appBar: AppBar(
      title: Text('Registrarse'),

    ),

      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 30.0 ),
        child: ScrollConfiguration(
            behavior: Scroll(),
            child: Form(
              key: _formKey,
            child: ListView(
              children: <Widget>[FlutterLogo(
                style: FlutterLogoStyle.markOnly,
              size: 200.0,),

                TextFormField(
                  autocorrect: false,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(labelText: 'Email'),
                  validator: (val){
                    if (val.isEmpty){
                      return 'Por favor ingrese un email valido';
                    } else {
                      return null;
                    }

                  },
                  onSaved: (val){
                    setState(() {
                      _email=val;
                    });
                  },

                ),

                TextFormField(
                  autocorrect: true,
                  decoration: InputDecoration(labelText: 'Contraseña'),
                  validator: (val){
                    if (val.isEmpty){
                      return 'Por favor ingrese una contraseña valida';
                    } else {
                      return null;
                    }

                  },

                  onSaved: (val){

                    setState(() {
                      _password= val;
                    });
                  },

                ),

                Padding(padding: EdgeInsets.symmetric(vertical: 20.0),
                child:  Text('Bienvenido a la App Educont',
                  style: TextStyle(
                      color: Color.fromARGB(200, 200, 200, 200)
                ),
                ),
                ),
              ],
            ),

      ),
      ),
      ),

      floatingActionButton: FloatingActionButton(onPressed: (){},
        child: Icon(Icons.person_add),

      ),

      persistentFooterButtons: <Widget>[
        FlatButton(onPressed: (){

          _Register();
          Navigator.of(context).pushNamed('/Login');
        },
          child: Text('Bienvenido a Eduncont'),
        ),
      ],

    );

  }


}