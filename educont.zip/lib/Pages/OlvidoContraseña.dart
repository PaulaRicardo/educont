import 'package:flutter/material.dart';

class OlvidoPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => _OlvidoPageState();
}

class _OlvidoPageState extends State<OlvidoPage>{
  @override
  Widget build(BuildContext context) {

    return Scaffold (appBar: AppBar(title: Text('Recordar contraseña'),

    ),

    );

  }


}