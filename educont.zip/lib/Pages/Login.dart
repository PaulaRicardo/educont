import 'package:educont_app/behaviors/Scroll.dart';
import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>{
  @override
  Widget build(BuildContext context) {

    return Scaffold (appBar: AppBar(title: Text('Login'),

    ),

    body: Container(
    padding: EdgeInsets.symmetric(horizontal: 30.0 ),
    child: ScrollConfiguration(
    behavior: Scroll(),
    child: Form(
    child: ListView(
    children: <Widget>[FlutterLogo(
    style: FlutterLogoStyle.markOnly,
    size: 200.0,),

    TextFormField(
    autocorrect: false,
    keyboardType: TextInputType.emailAddress,
    decoration: InputDecoration(labelText: 'Email'),

    ),

    TextFormField(
    autocorrect: true,
    decoration: InputDecoration(labelText: 'Contraseña'),

    ),

    Padding(padding: EdgeInsets.symmetric(vertical: 20.0),
    child:  Text('Bienvenido a la App Educont',
    style: TextStyle(
    color: Color.fromARGB(200, 200, 200, 200)
    ),
    ),
    ),

      FlatButton(child: Text('Olvide mi contraseña'),
        onPressed: (){
        Navigator.of(context).pushNamed('OlvidoContraseña');
        },

        textColor: Colors.purple,
      ),
    ],
    ),

    ),
    ),
    ),

    floatingActionButton: FloatingActionButton(onPressed: (){},
    child: Icon(Icons.account_circle),

    ),

    persistentFooterButtons: <Widget>[
    FlatButton(onPressed: (){
    Navigator.of(context).pop();
    },
    child: Text('No se encuentra registrado'),

    ),
    ],

    );

  }


}