import 'package:flutter/material.dart';

class TodosAchivosPage extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => _TodosAchivosPageState();

}

class _TodosAchivosPageState extends State<TodosAchivosPage>{
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title:  Text('Todos Los Archivos'),
      ),
      body: Center(
        child: Text('Bienvenido'),
      ),

    );
  }


}