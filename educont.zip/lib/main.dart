import 'package:flutter/material.dart';
import 'Pages/Register.dart';
import 'estilos.dart';
import 'rutas.dart';

void main() => runApp(TodoAqui());

class TodoAqui extends StatefulWidget {

  @override
  State<StatefulWidget> createState()=> _TodoAquiState();

}

class _TodoAquiState extends State<TodoAqui>{

  Widget rootPage = RegisterPage();


  @override
  Widget build(BuildContext context) {

    return MaterialApp(title: 'Educont',
      home: rootPage,
    routes: buildAppRoutes(),
      theme: buildAppTheme(),
    );

  }
}