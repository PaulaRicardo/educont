import 'package:flutter/material.dart';

class Scroll extends ScrollBehavior{
  @override

  Widget buildViewportChrone(BuildContext context, Widget child, AxisDirection axisDirection){

    return child;

  }

}
