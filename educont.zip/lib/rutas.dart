import 'package:flutter/material.dart';

import 'Pages/Login.dart';
import 'Pages/OlvidoContraseña.dart';
import 'Pages/Register.dart';
import 'Pages/mainTabs.dart';

Map<String,WidgetBuilder> buildAppRoutes() {
  return {
    '/Login': (BuildContext context) => LoginPage(),
    '/Register': (BuildContext context) => RegisterPage(),
    '/OlvidoContraseña': (BuildContext context) =>  OlvidoPage(),
    '/mainTabs': (BuildContext context) => MainTabsPage(),
  };
}